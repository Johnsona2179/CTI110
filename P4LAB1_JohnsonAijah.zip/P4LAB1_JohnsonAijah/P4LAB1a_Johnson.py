# Aijah Johnson

# P4LAB1a_JohnsonAijah

# April 4, 2024

# write a program that draws both a square and a triangle.

import turtle
win = turtle.Screen()  
t = turtle.Turtle()

#use for loop to create one square and one triangle

for s in range(4):
    turtle.forward(111)         # move forward 111 degrees
    turtle.left(90)             # move left 90 degrees

turtle.right(180)
turtle.forward(20)

for t in range(3):
    turtle.forward(111)         # move forward 111 degrees
    turtle.left(120)            # move left 120 degrees

# end command
win.mainloop()                  #wait for user to close window




