# Aijah Johnson

# P4LAB1a_JohnsonAijah

# April 4, 2024

# Using turtle graphics, write a program that displays your first and last initials.

import turtle
win = turtle.Screen()
t = turtle.Turtle()

# add display options
turtle.pensize (5)
turtle.pencolor("orange")

turtle.forward(100)
turtle.right(45)
turtle.forward(40)
turtle.backward(120)

turtle.right(90)
turtle.forward(120)


turtle.penup()
turtle.left(135)
turtle.forward(200)
turtle.left(90)
turtle.forward(100)
turtle.pendown()

turtle.right(90)
turtle.forward(90)
turtle.backward(45)
turtle.right(90)
turtle.forward(100)
turtle.right(90)
turtle.forward(45)
turtle.right(90)
turtle.forward(35)

win.mainloop()
